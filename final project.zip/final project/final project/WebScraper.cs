﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Threading.Tasks;

namespace final_project
{
    public class WebScraper
    {
        private static readonly HttpClient client = new HttpClient();

        public static async Task<List<string>> ScrapeMultiplePagesAsync(string[] urls)
        {
            var tasks = urls.Select(url => GetHtmlContentAsync(url)).ToArray();
            var htmlContents = await Task.WhenAll(tasks);

            Console.WriteLine(htmlContents);

            var allHeadlines = new List<string>();
            foreach (var html in htmlContents)
            {
                if (!string.IsNullOrEmpty(html))
                {
                    var headlines = HtmlParser.ExtractHeadlines(html);
                    allHeadlines.AddRange(headlines);
                }
            }

            return allHeadlines;
        }

        public static async Task<string> GetHtmlContentAsync(string url)
        {
            try
            {
                await Task.Delay(1000);
                string htmlContent = await client.GetStringAsync(url);
                return htmlContent;
            }
            catch (HttpRequestException httpEx)
            {
                Console.WriteLine($"Request error for {url}: {httpEx.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"General error for {url}: {ex.Message}");
            }
            return null;
        }

        public static async Task<List<string>> ScrapeInBatchesAsync(string[] urls, int batchSize)
        {
            var allHeadlines = new List<string>();
            for (int i = 0; i < urls.Length; i += batchSize)
            {
                var batch = urls.Skip(i).Take(batchSize).ToArray();
                var batchHeadlines = await ScrapeMultiplePagesAsync(batch);
                allHeadlines.AddRange(batchHeadlines);
            }

            return allHeadlines;
        }
    }
}

