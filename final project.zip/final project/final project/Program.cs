﻿using System.Net.Http;
using final_project;
using HtmlAgilityPack;
using System.IO;
using System.Text.Json.Serialization.Metadata;


class Program()
{
    public static void  Main(string[] argms)
    {
        WebScraper webScrapper = new WebScraper();
        List<string> titles = WebScraper.ScrapeInBatchesAsync(new string[] { "https://edition.cnn.com/", "https://www.nytimes.com/international/", "https://www.bbc.com/news" }, 1).Result;

        string filePath = "titles.txt";
        DataAggregator.WriteToCsv(titles, filePath);

        Console.WriteLine("Titles of the given links:");
        Console.WriteLine("---------------------------");
        foreach (string title in titles)
        {
            Console.WriteLine(title);
        }
        Console.WriteLine("---------------------------");
    }
}